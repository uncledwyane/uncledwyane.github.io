---
title: 音乐歌单收藏
date: 2019-07-30 10:43:45
---

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.css">
<script src="https://cdn.jsdelivr.net/npm/aplayer/dist/APlayer.min.js"></script>
<!-- require MetingJS -->
<script src="https://cdn.jsdelivr.net/npm/meting@2/dist/Meting.min.js"></script>
<meting-js style="width: auto;height: 2000px;"
    server="netease"
    type="playlist"
    id="2364053447"
    theme="#2980b9"
    loop="all"
    autoplay="false"
    order="list"
    storageName="aplayer-setting"
    lrctype= 0
    list-max-height="800px"
    >
</meting-js>
---
<p style="text-align:center;margin-top:30px"><span style="font-size:14px">温馨提示：选择喜欢的音乐双击播放，由于版权原因部分不能播放。如果喜欢歌单<a href="https://music.163.com/#/user/home?id=132033817" target="_blank" rel="noopener">收藏</a>一下，去网易云都能播放哟！<span></span></span></p>