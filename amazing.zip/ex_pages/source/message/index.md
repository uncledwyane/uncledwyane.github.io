---
thumbnail: http://wx2.sinaimg.cn/large/b5d1b710ly1g6s7jq3pi1j212w0k3n27.jpg
date: 2018-11-11 08:24:49
comments: true
---

**来而不往非礼也**  
**畅所欲言，有留必应**
